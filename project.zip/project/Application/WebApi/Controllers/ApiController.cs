﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace WebApi.Controllers
{
    [Route("api")]
    [ApiController]
    public class ApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public ApiController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        [HttpPost("messages")]
        public async Task<IActionResult> Post(Message message)
        {
            var id = Guid.NewGuid().ToString("N");

            using var client = new HttpClient();
            
            var response = await client.PostAsync(_configuration.GetValue<string>("CarrierEndpoint"),
                new StringContent(JsonConvert.SerializeObject(message), Encoding.UTF8, "application/json"));

            if (response.IsSuccessStatusCode)
            {
                var status = new MessageStatus
                {
                    Id = id,
                    Status = "sent"
                };

                await _context.Messages.AddAsync(status);
                await _context.SaveChangesAsync();
            }

            var result = new MessageStatus
            {
                Id = id,
                Status = "accepted"
            };

            return Ok(result);
        }
    }
}
