﻿using Microsoft.AspNetCore.Mvc;

namespace CarrierApi.Controllers
{
    [Route("api")]
    [ApiController]
    public class ApiController : ControllerBase
    {
        [HttpPost("carrier")]
        public IActionResult Post(object model)
        {
            return Ok();
        }
    }
}
